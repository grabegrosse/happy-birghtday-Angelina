(function () {
    'use strict';

    /* ============ SCROLL PROGRESS ============ */
    const progressBar = document.querySelector('.scroll-progress');
    window.addEventListener('scroll', () => {
        const docH = document.documentElement.scrollHeight - window.innerHeight;
        const pct = docH > 0 ? (window.scrollY / docH) * 100 : 0;
        progressBar.style.width = pct + '%';
    });

    /* ============ HEADER COMPACT ============ */
    const header = document.querySelector('.site-header');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 40) header.classList.add('compact');
        else header.classList.remove('compact');
    });

    /* ============ NAVIGATION (double-click) ============ */
    const pages = document.querySelectorAll('.page');
    const navItems = document.querySelectorAll('[data-nav]');

    function showPage(id) {
        pages.forEach(p => p.classList.toggle('active', p.id === id));
        window.scrollTo({ top: 0, behavior: 'smooth' });
        // update active nav
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        const matchingLink = document.querySelector(`.nav-link[data-nav="${id}"]`);
        if (matchingLink) matchingLink.classList.add('active');
        // re-run reveal for visible page
        requestAnimationFrame(() => initReveal());
    }

    navItems.forEach(item => {
        item.addEventListener('dblclick', (e) => {
            e.preventDefault();
            const target = item.getAttribute('data-nav');
            if (target === 'home') showPage('home');
            else if (target === 'section') showPage('section');
        });
        // prevent single click default jump
        item.addEventListener('click', (e) => {
            e.preventDefault();
        });
    });

    // default active
    document.querySelector('.nav-link[data-nav="section"]')?.classList.remove('active');
    document.querySelector('.logo')?.classList.add('active');

    /* ============ SCROLL REVEAL ============ */
    let revealObserver;
    function initReveal() {
        if (revealObserver) revealObserver.disconnect();
        revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    revealObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12 });
        const activePage = document.querySelector('.page.active');
        if (activePage) {
            activePage.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));
        }
    }
    initReveal();

    /* ============ BUTTERFLIES ============ */
    const layer = document.getElementById('butterfliesLayer');
    const BUTTERFLY_COUNT = 12;
    const butterflies = [];
    const mouse = { x: window.innerWidth / 2, y: window.innerHeight / 2, active: false };

    const butterflySVG = `
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        <g class="wing-left">
            <path d="M48 50 C 30 20, 5 15, 8 40 C 10 58, 30 60, 48 50 Z" fill="#ffffff" stroke="#e6d6dd" stroke-width="1.5"/>
            <path d="M48 50 C 35 65, 15 78, 20 92 C 28 100, 44 78, 48 52 Z" fill="#f7f0f3" stroke="#e6d6dd" stroke-width="1.5"/>
        </g>
        <g class="wing-right">
            <path d="M52 50 C 70 20, 95 15, 92 40 C 90 58, 70 60, 52 50 Z" fill="#ffffff" stroke="#e6d6dd" stroke-width="1.5"/>
            <path d="M52 50 C 65 65, 85 78, 80 92 C 72 100, 56 78, 52 52 Z" fill="#f7f0f3" stroke="#e6d6dd" stroke-width="1.5"/>
        </g>
        <ellipse cx="50" cy="52" rx="2.2" ry="14" fill="#5a4a52"/>
        <circle cx="50" cy="38" r="2.6" fill="#5a4a52"/>
        <path d="M50 36 C 46 30, 43 26, 41 22" stroke="#5a4a52" stroke-width="1.2" fill="none" stroke-linecap="round"/>
        <path d="M50 36 C 54 30, 57 26, 59 22" stroke="#5a4a52" stroke-width="1.2" fill="none" stroke-linecap="round"/>
    </svg>`;

    class Butterfly {
        constructor() {
            this.el = document.createElement('div');
            this.el.className = 'butterfly';
            this.el.innerHTML = butterflySVG;
            layer.appendChild(this.el);

            this.x = Math.random() * window.innerWidth;
            this.y = Math.random() * window.innerHeight;
            this.vx = (Math.random() - 0.5) * 1.4;
            this.vy = (Math.random() - 0.5) * 1.4;
            this.angle = 0;
            this.wanderTimer = 0;
            this.fleeCooldown = 0;
            this.baseSpeed = 0.7 + Math.random() * 0.5;
            this.size = 42;

            this.el.addEventListener('click', (e) => {
                e.stopPropagation();
                this.fleeFrom(mouse.x, mouse.y, true);
            });
        }

        fleeFrom(px, py, strong) {
            const dx = this.x - px;
            const dy = this.y - py;
            const dist = Math.hypot(dx, dy) || 1;
            const force = strong ? 9 : 2.4;
            this.vx += (dx / dist) * force;
            this.vy += (dy / dist) * force;
            this.fleeCooldown = 30;
        }

        update() {
            const w = window.innerWidth;
            const h = window.innerHeight;

            // wander
            this.wanderTimer--;
            if (this.wanderTimer <= 0) {
                this.vx += (Math.random() - 0.5) * 0.6;
                this.vy += (Math.random() - 0.5) * 0.6;
                this.wanderTimer = 40 + Math.random() * 60;
            }

            // evade cursor
            if (mouse.active) {
                const dx = this.x - mouse.x;
                const dy = this.y - mouse.y;
                const dist = Math.hypot(dx, dy);
                if (dist < 140 && dist > 0.001) {
                    const push = (140 - dist) / 140;
                    this.vx += (dx / dist) * push * 1.6;
                    this.vy += (dy / dist) * push * 1.6;
                }
            }

            // damping
            this.vx *= 0.94;
            this.vy *= 0.94;

            // maintain minimum speed
            const speed = Math.hypot(this.vx, this.vy);
            const minSpeed = this.baseSpeed;
            if (speed < minSpeed) {
                const a = Math.random() * Math.PI * 2;
                this.vx += Math.cos(a) * 0.15;
                this.vy += Math.sin(a) * 0.15;
            }
            if (speed > 6) {
                this.vx *= 0.85;
                this.vy *= 0.85;
            }

            this.x += this.vx;
            this.y += this.vy;

            // boundaries soft
            const pad = 30;
            if (this.x < pad) { this.x = pad; this.vx = Math.abs(this.vx) + 0.5; }
            if (this.x > w - pad) { this.x = w - pad; this.vx = -Math.abs(this.vx) - 0.5; }
            if (this.y < pad) { this.y = pad; this.vy = Math.abs(this.vy) + 0.5; }
            if (this.y > h - pad) { this.y = h - pad; this.vy = -Math.abs(this.vy) - 0.5; }

            // rotate toward motion
            const targetAngle = Math.atan2(this.vy, this.vx) * 180 / Math.PI + 90;
            let diff = targetAngle - this.angle;
            while (diff > 180) diff -= 360;
            while (diff < -180) diff += 360;
            this.angle += diff * 0.15;

            if (this.fleeCooldown > 0) this.fleeCooldown--;

            this.el.style.transform =
                `translate(${this.x - this.size / 2}px, ${this.y - this.size / 2}px) rotate(${this.angle}deg)`;
        }
    }

    for (let i = 0; i < BUTTERFLY_COUNT; i++) {
        butterflies.push(new Butterfly());
    }

    // mouse tracking
    window.addEventListener('mousemove', (e) => {
        mouse.x = e.clientX;
        mouse.y = e.clientY;
        mouse.active = true;
    });
    window.addEventListener('mouseleave', () => { mouse.active = false; });
    window.addEventListener('touchmove', (e) => {
        if (e.touches[0]) {
            mouse.x = e.touches[0].clientX;
            mouse.y = e.touches[0].clientY;
            mouse.active = true;
        }
    }, { passive: true });
    window.addEventListener('touchend', () => { mouse.active = false; });

    // animation loop
    function animate() {
        butterflies.forEach(b => b.update());
        requestAnimationFrame(animate);
    }
    animate();

    /* ============ SMOOTH ANCHOR (fallback) ============ */
    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', (e) => {
            if (!a.hasAttribute('data-nav')) {
                const target = document.querySelector(a.getAttribute('href'));
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });

})();